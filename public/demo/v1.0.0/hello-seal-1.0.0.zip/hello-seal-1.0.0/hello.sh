#!/bin/sh
echo "Hello from hello-seal 1.0.0"
