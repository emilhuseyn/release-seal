#!/bin/sh
echo "Hello from hello-seal 1.0.0"
echo "This copy was changed after the release was sealed."
